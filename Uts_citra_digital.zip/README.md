# Klasifikasi-Daun-Herbal
Latihan ini untuk mahasiswa yang mengambil kelas Pengolahan citra digital
akses dataset berikut https://drive.google.com/drive/folders/1KiUBrOCYAoq0HMb8YoAci0BfCwkUQk77?usp=sharing
